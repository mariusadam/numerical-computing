function y=xsin(x)
y=x.*sin(x);