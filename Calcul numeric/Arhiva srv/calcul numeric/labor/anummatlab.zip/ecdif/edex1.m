function yd=edex1(t,y)
yd=-y+t+1;