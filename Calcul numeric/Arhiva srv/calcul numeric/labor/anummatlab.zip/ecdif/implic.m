function z=implic(t,y,yp)
z=yp^2+y^2-1;
