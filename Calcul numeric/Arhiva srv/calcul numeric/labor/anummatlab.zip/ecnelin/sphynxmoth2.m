function c=sphynxmoth2
load sphynx
[w,ii]=sort(sphynx(:,1)); 
r=sphynx(ii,2);
