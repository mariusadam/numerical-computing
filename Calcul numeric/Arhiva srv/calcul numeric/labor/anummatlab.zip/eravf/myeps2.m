function z=myeps2
x=4/3-1;
y=3*x;
z=1-y;