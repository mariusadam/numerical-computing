%P3_6
s1='4059000000000000';
s2='3f847ae147ae147b';
s3='3fe921fb54442d18';
%conversii din hexazecimal in dubla precizie
hex2float(s1)
hex2float(s3)
hex2float(s2)
format hex
100
1/100
pi/4
