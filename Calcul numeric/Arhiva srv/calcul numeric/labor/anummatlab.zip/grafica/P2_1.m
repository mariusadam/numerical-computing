%P2_1
subplot(1,3,1)
lissajous(2,3,1,2)
subplot(1,3,2)
lissajous(5,7,9,4)
subplot(1,3,3)
lissajous(1,1,1,10)