%P2_2
subplot(1,3,1)
fluture(2,4,1/12,6)
subplot(1,3,2)
fluture(1,2,1/4,4)
subplot(1,3,3)
fluture(3,1,1/2,3)