function y=lsin(x)
y=sqrt(1+cos(x).^2);