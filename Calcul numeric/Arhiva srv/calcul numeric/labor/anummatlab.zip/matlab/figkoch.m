clf
subplot(1,2,1)
snowflake2
subplot(1,2,2)
snowflake2