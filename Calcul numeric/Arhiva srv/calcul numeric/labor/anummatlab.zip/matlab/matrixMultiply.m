function matrixMultiply(A, B)
try
   X = A * B
catch
   disp '** Error multiplying A * B'
end